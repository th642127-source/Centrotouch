package com.example.centrotouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.Point
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.hypot
import kotlin.math.max

class TouchAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TouchAccessibilityService? = null
        var radiusDp: Int = 70
        var centerX: Int = 420
        var centerY: Int = 900
    }

    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var enabled = true
    private var radiusPx = 0

    private var active = false
    private var syntheticPoint = PointF()
    private var queuedPoint: PointF? = null
    private var dispatching = false
    private var lastEventTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {
        cancelActive()
    }

    fun toggleOverlay() {
        enabled = !enabled
        if (enabled) refreshOverlay() else removeOverlay()
    }

    fun refreshOverlay() {
        if (!enabled || wm == null) return
        radiusPx = (radiusDp * resources.displayMetrics.density).toInt()
        removeOverlay()

        val size = radiusPx * 2
        val v = TouchCircleView().apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(45, 30, 100, 255))
                setStroke(max(2, radiusPx / 18), Color.argb(190, 30, 100, 255))
            }
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = centerX - radiusPx
        params.y = centerY - radiusPx

        overlay = v
        wm?.addView(v, params)
    }

    private fun removeOverlay() {
        overlay?.let {
            try { wm?.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        cancelActive()
    }

    private fun cancelActive() {
        active = false
        queuedPoint = null
        dispatching = false
    }

    private inner class TouchCircleView : View(this@TouchAccessibilityService) {
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val x = e.rawX
            val y = e.rawY

            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val dx = x - centerX
                    val dy = y - centerY
                    if (hypot(dx.toDouble(), dy.toDouble()) > radiusPx) return false

                    active = true
                    syntheticPoint.set(centerX.toFloat(), centerY.toFloat())
                    queuedPoint = null
                    dispatching = true
                    lastEventTime = e.eventTime

                    // The synthetic pointer begins at the exact configured center.
                    val path = Path().apply {
                        moveTo(centerX.toFloat(), centerY.toFloat())
                        lineTo(centerX.toFloat(), centerY.toFloat())
                    }
                    val stroke = GestureDescription.StrokeDescription(
                        path, 0, 1, true
                    )
                    dispatchGesture(
                        GestureDescription.Builder().addStroke(stroke).build(),
                        object : GestureDescription.GestureResultCallback() {
                            override fun onCompleted(gestureDescription: GestureDescription?) {
                                dispatching = false
                                queuedPoint?.let {
                                    queuedPoint = null
                                    continueTo(it, e.eventTime)
                                }
                            }
                            override fun onCancelled(gestureDescription: GestureDescription?) {
                                cancelActive()
                            }
                        },
                        null
                    )
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (!active) return false
                    val p = PointF(x, y)
                    if (dispatching) {
                        queuedPoint = p
                    } else {
                        continueTo(p, e.eventTime)
                    }
                    return true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (active) {
                        val p = PointF(x, y)
                        if (!dispatching) finishAt(p, e.eventTime)
                        else {
                            queuedPoint = p
                            // Release will occur after the pending segment.
                        }
                    }
                    return true
                }
            }
            return true
        }
    }

    private fun continueTo(p: PointF, eventTime: Long) {
        if (!active) return
        val start = PointF(syntheticPoint.x, syntheticPoint.y)
        val distance = hypot(
            (p.x - start.x).toDouble(),
            (p.y - start.y).toDouble()
        )
        val duration = max(1L, minOf(120L, (distance / 1.5).toLong()))
        val path = Path().apply {
            moveTo(start.x, start.y)
            lineTo(p.x, p.y)
        }

        dispatching = true
        val stroke = GestureDescription.StrokeDescription(path, 0, duration, true)
        syntheticPoint.set(p.x, p.y)
        lastEventTime = eventTime

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureDescription.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    dispatching = false
                    val q = queuedPoint
                    queuedPoint = null
                    if (q != null) continueTo(q, System.currentTimeMillis())
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    cancelActive()
                }
            },
            null
        )
    }

    private fun finishAt(p: PointF, eventTime: Long) {
        if (!active) return
        val start = PointF(syntheticPoint.x, syntheticPoint.y)
        val path = Path().apply {
            moveTo(start.x, start.y)
            lineTo(p.x, p.y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 1, false)
        active = false
        dispatching = true
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureDescription.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    dispatching = false
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    dispatching = false
                }
            },
            null
        )
    }
}
