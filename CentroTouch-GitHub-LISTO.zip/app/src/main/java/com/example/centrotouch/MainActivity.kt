package com.example.centrotouch

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "CentroTouch"
            textSize = 28f
        }
        val info = TextView(this).apply {
            text = "\n1. Activa el servicio de accesibilidad.\n2. Usa el círculo superpuesto para iniciar arrastres desde su centro.\n3. El radio se puede ajustar aquí.\n\nNota: esta versión inicial usa el centro configurado y el círculo se muestra sobre otras apps."
            textSize = 16f
        }

        val radiusText = TextView(this).apply { text = "Radio: ${TouchAccessibilityService.radiusDp} dp" }
        val radius = SeekBar(this).apply {
            max = 150
            progress = TouchAccessibilityService.radiusDp - 20
        }
        radius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                TouchAccessibilityService.radiusDp = p + 20
                radiusText.text = "Radio: ${TouchAccessibilityService.radiusDp} dp"
                TouchAccessibilityService.instance?.refreshOverlay()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val accessibility = Button(this).apply {
            text = "Abrir accesibilidad"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val toggle = Button(this).apply {
            text = "Activar / desactivar círculo"
            setOnClickListener {
                TouchAccessibilityService.instance?.toggleOverlay()
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(radiusText)
        root.addView(radius)
        root.addView(accessibility)
        root.addView(toggle)
        setContentView(root)
    }
}
