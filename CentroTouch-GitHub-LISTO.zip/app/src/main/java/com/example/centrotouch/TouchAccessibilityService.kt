\
    package com.example.centrotouch

    import android.accessibilityservice.AccessibilityService
    import android.accessibilityservice.GestureDescription
    import android.graphics.Color
    import android.graphics.Path
    import android.graphics.PointF
    import android.graphics.drawable.GradientDrawable
    import android.view.Gravity
    import android.view.MotionEvent
    import android.view.View
    import android.view.WindowManager
    import kotlin.math.hypot
    import kotlin.math.max

    class TouchAccessibilityService : AccessibilityService() {

        companion object {
            var instance: TouchAccessibilityService? = null
            var radiusDp: Int = 70
            var centerX: Int = 420
            var centerY: Int = 900
        }

        private var wm: WindowManager? = null
        private var overlay: View? = null
        private var enabled = true
        private var radiusPx = 0

        private var active = false
        private var dispatching = false
        private var currentStroke: GestureDescription.StrokeDescription? = null
        private var queuedPoint: PointF? = null
        private var releasePending = false
        private val syntheticPoint = PointF()

        override fun onServiceConnected() {
            super.onServiceConnected()
            instance = this
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            refreshOverlay()
        }

        override fun onDestroy() {
            removeOverlay()
            instance = null
            super.onDestroy()
        }

        override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

        override fun onInterrupt() {
            cancelActive()
        }

        fun toggleOverlay() {
            enabled = !enabled
            if (enabled) refreshOverlay() else removeOverlay()
        }

        fun refreshOverlay() {
            if (!enabled || wm == null) return
            radiusPx = (radiusDp * resources.displayMetrics.density).toInt()
            removeOverlay()

            val size = radiusPx * 2
            val v = TouchCircleView().apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(45, 30, 100, 255))
                    setStroke(max(2, radiusPx / 18), Color.argb(190, 30, 100, 255))
                }
            }

            val params = WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            params.x = centerX - radiusPx
            params.y = centerY - radiusPx

            overlay = v
            wm?.addView(v, params)
        }

        private fun removeOverlay() {
            overlay?.let {
                try { wm?.removeView(it) } catch (_: Exception) {}
            }
            overlay = null
            cancelActive()
        }

        private fun cancelActive() {
            active = false
            dispatching = false
            currentStroke = null
            queuedPoint = null
            releasePending = false
        }

        private inner class TouchCircleView : View(this@TouchAccessibilityService) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                val x = e.rawX
                val y = e.rawY

                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        val dx = x - centerX
                        val dy = y - centerY
                        if (hypot(dx.toDouble(), dy.toDouble()) > radiusPx) return false

                        active = true
                        dispatching = true
                        queuedPoint = null
                        releasePending = false
                        syntheticPoint.set(centerX.toFloat(), centerY.toFloat())

                        val path = Path().apply {
                            moveTo(centerX.toFloat(), centerY.toFloat())
                            lineTo(centerX.toFloat(), centerY.toFloat())
                        }

                        currentStroke = GestureDescription.StrokeDescription(
                            path, 0, 1, true
                        )

                        dispatchCurrentStroke()
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        if (!active) return false
                        queueOrContinue(PointF(x, y), false)
                        return true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!active) return true
                        queueOrContinue(PointF(x, y), true)
                        return true
                    }
                }
                return true
            }
        }

        private fun queueOrContinue(point: PointF, release: Boolean) {
            queuedPoint = point
            if (release) releasePending = true
            if (!dispatching) dispatchQueued()
        }

        private fun dispatchQueued() {
            if (!active) return

            val point = queuedPoint ?: return
            queuedPoint = null

            val start = PointF(syntheticPoint.x, syntheticPoint.y)
            val distance = hypot(
                (point.x - start.x).toDouble(),
                (point.y - start.y).toDouble()
            )
            val duration = max(1L, minOf(80L, (distance / 1.8).toLong()))

            val path = Path().apply {
                moveTo(start.x, start.y)
                lineTo(point.x, point.y)
            }

            val release = releasePending
            releasePending = false

            val previous = currentStroke ?: run {
                cancelActive()
                return
            }

            currentStroke = previous.continueStroke(
                path,
                0,
                duration,
                !release
            )
            syntheticPoint.set(point.x, point.y)
            dispatching = true
            dispatchCurrentStroke()
        }

        private fun dispatchCurrentStroke() {
            val stroke = currentStroke ?: run {
                cancelActive()
                return
            }

            dispatchGesture(
                GestureDescription.Builder().addStroke(stroke).build(),
                object : GestureDescription.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        dispatching = false

                        // If the stroke ended the pointer, finish.
                        if (!stroke.willContinue()) {
                            active = false
                            currentStroke = null
                            queuedPoint = null
                            releasePending = false
                            return
                        }

                        // Process the latest physical position as soon as possible.
                        if (queuedPoint != null) {
                            dispatchQueued()
                        }
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        cancelActive()
                    }
                },
                null
            )
        }
    }
