# CentroTouch — compilar desde un teléfono

Esta versión incluye GitHub Actions para que GitHub compile el APK sin Android Studio.

## Pasos

1. En el teléfono abre https://github.com/ y crea/inicia sesión en tu cuenta.
2. Crea un repositorio nuevo, por ejemplo `CentroTouch`.
3. Abre el repositorio y pulsa **Add file → Upload files**.
4. Sube TODOS los archivos y carpetas de este proyecto, incluyendo `.github/workflows/build-apk.yml`.
   No subas solamente el ZIP.
5. Pulsa **Commit changes**.
6. Entra en la pestaña **Actions**.
7. Abre **Build CentroTouch APK**.
8. Cuando termine correctamente, abre la ejecución y busca **Artifacts**.
9. Descarga `CentroTouch-debug`.
10. Descomprime el archivo descargado y abre `app-debug.apk`.
11. Si Android pregunta, permite instalar aplicaciones desde esa fuente.
12. Abre CentroTouch y activa su servicio de accesibilidad.

Si GitHub muestra un error rojo en Actions, no continúes instalando: copia aquí el mensaje del error y lo corregimos.
